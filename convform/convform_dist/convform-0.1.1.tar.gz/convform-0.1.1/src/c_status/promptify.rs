pub fn promptify(dumb_answer: String) -> String {
    dumb_answer
}
